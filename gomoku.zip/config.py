params = {
    "board_size": 15,
    "alpha": 10
}