import numpy as np

from config import params

def eval_one_line(line, player):
    #find some 'threat' patterns like open two, open three, and so on..
    #will find _oo_, _ooo__, __ooo_, _oooo_, _oooo, ooooo, _ooo_ where _ is empty and o is my stone
    line_length = len(line)
    length = -1
    one_side_closed = True
    blank_exist = False
    len1, len2, len3, len4, len5 = 0, 0, 0, 0, 0
    len_num_list = [len1, len2, len3, len4, len5]
    if player == "black":
        for n, i in enumerate(line):
            if i == 0:
                if (length > 0 or (one_side_closed == True and length == 0)) and n+1 < line_length and line[n+1] == 1 and blank_exist == False:
                    blank_exist = True
                    pass
                elif length > 0:
                    idx = length - 1
                    len_num_list[idx] += 1
                    length = 0
                else:
                    length = 0
                one_side_closed = False
            elif i == 1 : length += 1
            if i == 2 or (i==1 and n == line_length-1):
                if length > 1:
                    if one_side_closed == False:
                        idx = (length - 1) - 1
                        len_num_list[idx] += 1
                        length = 0
                    elif one_side_closed == True:
                        length = 0
                        one_side_closed = False
                elif length == 1:
                    length = 0
                if n+1<line_length and line[n+1] == 1:
                    length -= 1
                    one_side_closed = True
    #end
    else:  #white player
        for n, i in enumerate(line):
            if i == 0:
                if (length > 0 or (one_side_closed == True and length == 0)) and n+1 < line_length and line[n+1] == 2 and blank_exist == False:
                    blank_exist = True
                    pass
                if length > 0:
                    idx = length - 1
                    len_num_list[idx] += 1
                    length = 0
                else:
                    length = 0
                one_side_closed = False
            elif i == 2 : length += 1
            if i == 1 or (i==2 and n == line_length-1):
                if length > 1:
                    if one_side_closed == False:
                        idx = (length - 1) - 1
                        len_num_list[idx] += 1
                        length = 0
                    elif one_side_closed == True:
                        length = 0
                        one_side_closed = False
                elif length == 1:
                    length = 0
                if n + 1 < line_length and line[n + 1] == 2:
                    length -= 1
                    one_side_closed = True
    #end
    alpha = params['alpha']
    total_score = 0
    for idx, num in enumerate(len_num_list):
        total_score += num*(alpha**idx)
    return total_score

def evaluate(board, player):
    #evaluate heuristic score of the board given player(0 == empty, 1 == black stone, 2 == white stone)
    #one searches 'threats' like open two, open three, and so on..
    size = params['board_size']

    #search board horizontally
    total_score = 0
    for one_line in board:
        total_score += eval_one_line(one_line, player)

    #search board vertically
    for one_line in np.transpose(board):
        total_score += eval_one_line(one_line, player)

    #search board diagonally1 (upper left direction)
    for i in range(size):
        idx = -size//2 + i
        one_line = np.diag(board, idx)
        total_score += eval_one_line(one_line, player)

    #search board diagonally2 (upper right direction)
    board_flipped = np.fliplr(board)
    for i in range(size):
        idx = -size // 2 + i
        one_line = np.diag(board_flipped, idx)
        total_score += eval_one_line(one_line, player)

    return total_score





    """
    _ : state 0, o : state 1, x : state 2,
    __ : state 3, _o: state 4,
    __o : state 5, _oo : state 6,
    __oo: state 7, _ooo : state 8,
    __ooo: state 9, _oooo : state 10
    __oooo: state 11
    """
    """
    state = 2
    pattern = ""
    pattern_end = False
    for i in line:
        character = '_' if i == 0 else 'o' if i == 1 else 'x'
        if character == 'x':
            pattern_end = True
        else:
            pattern += character
        if len(pattern)>=3 and pattern[-3:] == "___":
            pattern = pattern[:-1]
        if pattern == "_oo_":
            pass
        elif pattern == ""
    """